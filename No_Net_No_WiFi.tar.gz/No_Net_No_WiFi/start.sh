#!/bin/bash
cppython No_Net_No_WiFi.py