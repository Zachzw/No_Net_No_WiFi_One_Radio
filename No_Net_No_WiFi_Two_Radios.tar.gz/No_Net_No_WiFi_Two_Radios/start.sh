#!/bin/bash
cppython No_Net_No_WiFi_Two_Radios.py